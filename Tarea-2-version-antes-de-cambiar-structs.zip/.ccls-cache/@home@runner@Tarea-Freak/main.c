
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "hashmap.h"
#include "list.h"
#include "arraylist.h"

typedef struct
{
  void *head;
  void *next;

}pila;

typedef struct{

  pila *versionesJugador;
  char *nombre;
  long puntosHabilidad;
  int nObjetos;
  HashMap *items;
}jugador;




/*1. Crear perfil de jugador/a (nombre): El/la usuario/a ingresa un nombre de jugador/a y se crea un perfil en la aplicación. La cantidad de puntos de habilidad se inicializa en 0, y se genera un inventario vacío que almacenará los items que obtenga el/la jugador/a  a lo largo del juego.*/  

void crearPerfil(HashMap *jugadores)
{
  jugadores->key=
  
  printf("Ingrese el nombre del jugadro");
  scanf("%[s/^n]",jugadores->);
}


/*2. Mostrar perfil de jugador/a (nombre): El/la usuario/a ingresa el nombre de un/a jugador/a y la aplicación muestra su nombre, cantidad de puntos de habilidad y su inventario de items que ha obtenido hasta el momento.*/

/*3. Agregar item a jugador/a (nombre, item): El/la usuario/a ingresa el nombre de un/a jugador/a y el nombre de un item que ha obtenido. La aplicación agrega el item al inventario de el/la jugador/a. Si el/la jugador/a no existe, se debe mostrar un aviso.*/

/*4. Eliminar item de jugador/a (nombre, item): El/la usuario/a ingresa el nombre de un/a jugador/a y el nombre de un item que desea eliminar. La aplicación elimina el item del inventario de el/la jugador/a. Si el/la jugador/a no existe o el item no está en el inventario, se debe mostrar un aviso.*/

/*5. Agregar puntos de habilidad a el/la jugador/a (nombre, puntos): El/la usuario/a ingresa el nombre de un/a jugador/a y la cantidad de puntos de habilidad obtenidos. Los puntos son sumados a la habilidad de el/la jugador/a.*/

/*6. Mostrar jugador@s con item específico (item): Se muestran todos los jugadores que tienen el item especificado.*/

/*7. Deshacer última acción de jugador/a (nombre): El/la usuario/a ingresa el nombre de un/a jugador/a y la aplicación deshace la última acción realizada por el/la jugador/a, ya sea agregar/eliminar un item o aumentar los puntos de habilidad. Si no hay acciones que deshacer para el/la jugador/a, se debe mostrar un aviso.*/

/*8. Exportar datos de jugadores a archivo de texto (nombre_archivo): La aplicación exporta los datos de todos los/las jugadores/as registrados a un archivo de texto indicado por el/la usuario/a. */

/*9. Cargar datos de jugadores desde un archivo de texto (nombre_archivo): La aplicación carga los datos de los/las jugadores/as registrados desde un archivo de texto indicado por el/la usuario/a. */






int main(void) {
  
  HashMap *jugadores=malloc(sizeof(jugador));
  crearPerfil(jugadores);
  
  
  return 0;
}
