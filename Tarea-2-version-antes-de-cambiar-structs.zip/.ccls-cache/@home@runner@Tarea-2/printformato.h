#ifndef PRINTFORMATO_H
#define PRINTFORMATO_H
#include "hashmap.h"

void printMenu();
void printMensajeGeneroJugadorCorrectamente();
void mostrarDatosJugador();
#endif // PRINTFORMATO_H
